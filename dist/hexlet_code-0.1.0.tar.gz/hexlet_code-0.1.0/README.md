### Hexlet tests and linter status:
[![Actions Status](https://github.com/HoldCarter/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HoldCarter/python-project-50/actions)


[![gendiff](https://github.com/HoldCarter/python-project-50/actions/workflows/gendiff_auto.yml/badge.svg)](https://github.com/HoldCarter/python-project-50/actions/workflows/gendiff_auto.yml)


<a href="https://codeclimate.com/github/HoldCarter/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/caab6a64f7eb270a88cf/maintainability" /></a>

<a href="https://codeclimate.com/github/HoldCarter/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/caab6a64f7eb270a88cf/test_coverage" /></a>

gendiff plain: https://asciinema.org/a/cZnFkHBYHksr0v9N2krCaHs2b
