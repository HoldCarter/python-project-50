# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pytest-cov>=4.0.0,<5.0.0', 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff_run:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/HoldCarter/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/HoldCarter/python-project-50/actions)\n\n\n[![gendiff](https://github.com/HoldCarter/python-project-50/actions/workflows/gendiff_auto.yml/badge.svg)](https://github.com/HoldCarter/python-project-50/actions/workflows/gendiff_auto.yml)\n\n\n<a href="https://codeclimate.com/github/HoldCarter/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/caab6a64f7eb270a88cf/maintainability" /></a>\n\n<a href="https://codeclimate.com/github/HoldCarter/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/caab6a64f7eb270a88cf/test_coverage" /></a>\n\ngendiff plain: https://asciinema.org/a/cZnFkHBYHksr0v9N2krCaHs2b\n',
    'author': 'HoldCarter',
    'author_email': 'holdcarter@holdcarter.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
