from gendiff.gendiff import generate_diff


def main():
    generate_diff()


if __name__ == '__main__':
    main()
